<?php
session_start();
echo $_SESSION['alphago_em'] . "wef";
session_destroy();
?>